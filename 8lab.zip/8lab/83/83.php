<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = htmlspecialchars(trim($_POST['fullname']));
    $username = htmlspecialchars(trim($_POST['username']));
    $password = htmlspecialchars(trim($_POST['password']));
    $birthdate = htmlspecialchars(trim($_POST['birthdate']));

    // Простейшая валидация данных
    $errors = [];
    if (empty($fullname)) {
        $errors[] = "ФИО не может быть пустым";
    }
    if (empty($username)) {
        $errors[] = "Логин не может быть пустым";
    }
    if (empty($password)) {
        $errors[] = "Пароль не может быть пустым";
    }
    if (empty($birthdate)) {
        $errors[] = "Дата рождения не может быть пустой";
    }

    if (empty($errors)) {
        // Сохранить данные в базу данных или выполнить другие действия
        echo "*Регистрация успешно завершена!*";
    } else {
        foreach ($errors as $error) {
            echo "*Ошибка:* $error\n";
        }
    }
}
?>
