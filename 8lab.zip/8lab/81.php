<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Таблица умножения</title>
    <style>
        table {
            width: 50%;
            border-collapse: collapse;
            margin: 50px 0;
            font-size: 18px;
            text-align: left;
        }
        th, td {
            padding: 12px;
            border: 1px solid #dddddd;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<table>
    <thead>
        <tr>
            <th>x</th>
            <?php
                for ($i = 0; $i <= 10; $i++) {
                    echo "<th>$i</th>";
                }
            ?>
        </tr>
    </thead>
    <tbody>
    <?php
        for ($row = 0; $row <= 10; $row++) {
            echo "<tr>";
            echo "<th>$row</th>";
            for ($col = 0; $col <= 10; $col++) {
                $result = $row * $col;
                echo "<td>$result</td>";
            }
            echo "</tr>";
        }
    ?>
    </tbody>
</table>

</body>
</html>
