<?php

function generate_calendar($month = null, $year = null) {
    if ($month === null) {
        $month = date('n');
    }
    if ($year === null) {
        $year = date('Y');
    }

    $daysOfWeek = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
    $monthDays = cal_days_in_month(CAL_GREGORIAN, $month, $year);
    $firstDayOfMonth = date('N', strtotime("$year-$month-01"));
    $holidays = [
        '01-01', // Новый Год
        '07-01', // Рождество Христово
    ];

    echo "<table border='1'>";
    echo "<tr>";

    foreach ($daysOfWeek as $day) {
        echo "<th>$day</th>";
    }
    
    echo "</tr><tr>";

    for ($i = 1; $i < $firstDayOfMonth; $i++) {
        echo "<td></td>";
    }

    for ($day = 1; $day <= $monthDays; $day++) {
        $currentDate = sprintf('%02d-%02d', $month, $day);
        $dayOfWeek = date('N', strtotime("$year-$month-$day"));
        $style = "";

        if (in_array($currentDate, $holidays)) {
            $style = "style='background-color: #FFDDC1;'"; // Цвет для праздничных дней
        } elseif ($dayOfWeek >= 6) {
            $style = "style='background-color: #FFCCCC;'"; // Цвет для выходных (суббота и воскресенье)
        }

        echo "<td $style>$day</td>";

        if ($dayOfWeek == 7) {
            echo "</tr><tr>";
        }
    }

    echo "</tr>";
    echo "</table>";
}

// Пример использования функции
generate_calendar();
?>
