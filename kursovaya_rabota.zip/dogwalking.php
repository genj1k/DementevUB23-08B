<!DOCTYPE html>
<html>

<head>
    <title>Выгул собак</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background-image: url('https://gas-kvas.com/uploads/posts/2023-02/1675460864_gas-kvas-com-p-sobaki-na-fonovii-risunok-22.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: flex-start;
            align-items: center;
            height: 100vh;
        }

        .content {
            margin-left: 20px;
            text-align: left;
            color: #ffffff;
        }

        .title {
            font-size: 50px;
            font-weight: bold;
        }

        .subtitle {
            font-size: 50px;
            font-weight: bold;
        }

        .description {
            font-size: 50px;
            font-weight: bold;
        }

        .button {
            margin-top: 20px;
            padding: 15px 30px;
            background-color: orange;
            color: #ffffff;
            text-transform: uppercase;
            text-decoration: none;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            display: inline-block;
        }
    </style>
</head>

<body>
    <div class="content">
        <div class="title">Надежные</div>
        <div class="subtitle">выгульщики собак</div>
        <div class="description">в вашем городе!</div>
        <div style="margin-top: 20px;"> 
    </div>
    <a href="finddogsitter.php" class="button">Найти выгульщика</a>
</body>

</html>